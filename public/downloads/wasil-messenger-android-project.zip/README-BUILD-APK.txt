Wasil Messenger Android APK / Play Store Build Kit (1.0.0)
============================================================================

Package ID: com.wasil.messenger
Default Live URL: https://whats-app-px5v.vercel.app

Option A — Build APK directly with Android Studio or Gradle:
  1. Open the "android/" folder in Android Studio (or run inside android/):
       gradle wrapper --gradle-version 8.5
       ./gradlew assembleDebug
     Or for signed Play Store / distribution release:
       ./gradlew assembleRelease
  2. Output APK location:
       android/app/build/outputs/apk/debug/app-debug.apk

Option B — Build Trusted Web Activity (TWA) via Bubblewrap CLI:
  npx @bubblewrap/cli init --manifest=https://whats-app-px5v.vercel.app/manifest.json
  npx @bubblewrap/cli build
