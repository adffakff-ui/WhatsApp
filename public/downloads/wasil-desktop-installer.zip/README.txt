Wasil Messenger (1.0.0) - Desktop Standalone Installer
================================================================

1. Windows (Shortcut + Standalone Window):
   - Double-click Install-Wasil-Windows.bat to launch immediately in app mode.
   - Or right-click Install-Wasil-Windows.ps1 -> "Run with PowerShell" to create a Desktop shortcut.

2. Linux:
   - Copy wasil-messenger.desktop to ~/.local/share/applications/ and run:
     chmod +x ~/.local/share/applications/wasil-messenger.desktop

App Origin: https://wasil-messenger.vercel.app
Package ID: com.wasil.messenger
