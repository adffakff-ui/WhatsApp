param(
  [string]$AppUrl = "https://whats-app-px5v.vercel.app/"
)
$ErrorActionPreference = "Stop"
$browsers = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe"
)
$browser = $browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) {
  Start-Process $AppUrl
  exit 0
}
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Wasil Messenger.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $browser
$shortcut.Arguments = "--app=$AppUrl --class=WasilMessenger"
$shortcut.Description = "Wasil Messenger - Encrypted Chat"
$shortcut.Save()
Write-Host "Shortcut created on Desktop: $shortcutPath"
Start-Process $browser "--app=$AppUrl"
